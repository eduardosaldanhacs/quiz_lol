import java.util.Scanner;

public class Ex5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] vetor = new int[10];
        int pares = 0;
        int maior;

        // Leitura dos valores
        System.out.println("Digite 10 números inteiros:");
        for (int i = 0; i < vetor.length; i++) {
            System.out.print("Valor " + (i + 1) + ": ");
            vetor[i] = scanner.nextInt();

            if (vetor[i] % 2 == 0) {
                pares++;
            }
        }

        // Inicializa 'maior' com o primeiro valor do vetor
        maior = vetor[0];

        // Encontra o maior valor
        for (int i = 1; i < vetor.length; i++) {
            if (vetor[i] > maior) {
                maior = vetor[i];
            }
        }

        // Saída dos resultados
        System.out.println("\nQuantidade de valores pares: " + pares);
        System.out.println("Maior valor armazenado: " + maior);

        scanner.close();
    }
}
