import java.util.Scanner;

public class Ex2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double nota1 = lerNotaValida(scanner, "primeira");
        double nota2 = lerNotaValida(scanner, "segunda");
        double nota3 = lerNotaValida(scanner, "terceira");

        // Cálculo da média ponderada
        double media = (nota1 * 2 + nota2 * 3 + nota3 * 5) / 10;

        // Exibição do resultado
        System.out.printf("Média final: %.2f%n", media);

        if (media >= 7.0) {
            System.out.println("Situação: Aprovado");
        } else {
            System.out.println("Situação: Reprovado");
        }

        scanner.close();
    }

    // Método auxiliar para ler uma nota válida entre 0 e 10
    public static double lerNotaValida(Scanner scanner, String ordem) {
        double nota;
        do {
            System.out.print("Digite a " + ordem + " nota (0 a 10): ");
            nota = scanner.nextDouble();

            if (nota < 0 || nota > 10) {
                System.out.println("Nota inválida. Por favor, digite um valor entre 0 e 10.");
            }
        } while (nota < 0 || nota > 10);
        return nota;
    }
}