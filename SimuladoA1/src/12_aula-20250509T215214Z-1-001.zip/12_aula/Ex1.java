import java.util.Scanner;

public class Ex1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Entrada do usuário
        System.out.print("Digite um número: ");
        int numero = scanner.nextInt();

        // Processamento
        int antecessor = numero - 1;
        int sucessor = numero + 1;

        // Saída
        System.out.println("Número digitado: " + numero);
        System.out.println("Antecessor: " + antecessor);
        System.out.println("Sucessor: " + sucessor);

        scanner.close();
    }
}