import java.util.Scanner;

public class Ex3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n;

        // Validação da entrada
        do {
            System.out.print("Digite um número inteiro maior que zero: ");
            n = scanner.nextInt();

            if (n <= 0) {
                System.out.println("Valor inválido. Tente novamente.");
            }
        } while (n <= 0);

        // Impressão do padrão
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print("*");
            }
            System.out.println(); // Quebra de linha após cada linha de asteriscos
        }

        scanner.close();
    }
}
