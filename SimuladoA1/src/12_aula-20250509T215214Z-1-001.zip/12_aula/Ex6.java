import java.util.Scanner;

public class Ex6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[][] matriz = new int[3][3];

        // Leitura com validação
        System.out.println("Digite valores inteiros positivos para preencher a matriz 3x3:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                int valor;
                do {
                    System.out.print("Valor para posição [" + i + "][" + j + "]: ");
                    valor = scanner.nextInt();
                    if (valor <= 0) {
                        System.out.println("Valor inválido. Digite um número inteiro positivo.");
                    }
                } while (valor <= 0);
                matriz[i][j] = valor;
            }
        }

        // Exibindo a diagonal principal
        System.out.println("\nElementos da diagonal principal:");
        for (int i = 0; i < 3; i++) {
            System.out.println("matriz[" + i + "][" + i + "] = " + matriz[i][i]);
        }

        scanner.close();
    }
}
