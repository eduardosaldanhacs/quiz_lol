import java.util.Scanner;

public class Ex4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n;

        // Validação da entrada
        do {
            System.out.print("Digite um número inteiro positivo: ");
            n = scanner.nextInt();
            if (n <= 0) {
                System.out.println("Valor inválido. Tente novamente.");
            }
        } while (n <= 0);

        int contador = 1;

        // Impressão do Triângulo de Floyd
        for (int i = 1; i <= n; i++) { // controla o número de linhas
            for (int j = 1; j <= i; j++) { // imprime os números por linha
                System.out.print(contador);
                contador++;
            }
            System.out.println(); // quebra de linha
        }

        scanner.close();
    }
}